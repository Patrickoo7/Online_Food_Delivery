export class ProdModel {
    id : number = 0;
    food: string='';
    price: string='';
    offer: string='';
  description: any;
}