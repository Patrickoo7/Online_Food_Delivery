export class OrderModel {
    id : number = 0;
    food: string='';
    tag: string='';
    phone: string='';
    addres: string='';
}